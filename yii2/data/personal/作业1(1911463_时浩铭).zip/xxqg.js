// ==UserScript==
// @name         xxgq
// @namespace    qyft
// @version      0.1
// @description  xxgq
// @author       qtfy
// @match        https://pc.xuexi.cn/points/exam-practice.html
// @match        https://pc.xuexi.cn/points/exam-weekly-list.html
// @match        https://pc.xuexi.cn/points/exam-paper-list.html
// @match        https://pc.xuexi.cn/points/exam-weekly-detail.html?id=*
// @match        https://pc.xuexi.cn/points/exam-paper-detail.html?id=*
// @icon         data:image/gif;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAADeUlEQVRIie2WbWhWZRjH/5vnCaIPQSNMocYTjD70MjWWYumYQ2tiG1YoSkzLaVRQiLZyFUQfil6s5UgGg4Fkhhiuxd7SvTrcRDcjpfq4F9CtfGboBN15nnN+fbjceXp8XiYY2YfdcOBwn+u6fv/7uq/7uk+WK6HbMLJvB3QWPAtOGKFz5+X81+DQxs2S78m7BdCcG2GuRKaHkrXgurBhE66Er7thxZqMPgn+9y+Awz9AXz8MDQXzGcF8uhvG/zCnsvU2d/IUXLtG7AbbqATlFXgSMQnK1kNPL7S24SsLStdB/4nMYFaVQfGzxCQ8Cc6dh+XP2Lf6fbDn67htQRHU1sHoKABoPigH3tgBeQXXs3QHjI2DctKDfTmQuxAmJ6FoNeyuhj8vwJmzoAfhyhW8BHvB4hWwcDn8csbEPPYkaH5cXGc3vLglgZME5pPPLU1ffGWrvRABz7PVRCZg1/sJ4MBvxzvw3gf2/uZOuHTZ0l+6Dhoak+yTwW/tgsHT9t7aBnkF4OTFBVz8C1zX9rGyCrqPmcCfjgappaExEMfAYEqhKVItqK3Dnd7f5zdCRxd8/Blsfc3Aq8osaHmFiQk/DpOTRKeLLBaDRYWw+rkgCzOCg5UXlkBXD2x73YK99AoMDcGS4rjN3lrYsAkeWQqjo/F5zbOMHGkHzUsZP6mBOHIU+v6wtGyxvKJCqfW4nKZmKZwrLxxW9ERH3Dj3AWlRvnSyXYpMyJEUKq9QVGN2yS/IV1RjqTtKUAxLV8LmbVaB11XS1GxF9Y+DH6zqvkftCJ0asMx09VgcsC1SGLqPpe0RBu7rt32prEr46El2Hn/7HVpaoaeX6DR4STGMjIDutXO7shSmpuDtd20BV69C25EZwL4P7Z3JnWjZ09apXBe++RbWvJAyiCfB8DBsrzSB1TVW8fsPzACu3xfvTPlPwdEOU3zpsjWSkrVpA0QlaG6BL/fAxEU4eMji7D+Q1DQyVnVMgrp62PKqBT39cyAqZfXX7IWch2FgEHqPQ3OLzY+N46fxcSWSrlhfUvbWl+VJN/f7OTUldX4nNTZJjiOvqlKhg4ekSESxDG4p73ZfklNdI+XcI82dK911Z9oA/s7tyo7FpOER6eyvmpNXIPm+1PBjZsHpUuFKdln09cNDT6S1cSX48KOU/TjTk+XeZEb/7fH//9mbBd/q+BuapkzTsaP4XQAAAABJRU5ErkJggg==
// @require      https://code.jquery.com/jquery-3.3.1.min.js
// ==/UserScript==

function sleep(time) {
    return new Promise((resolve) => setTimeout(resolve, time));
}

async function solve(num) {
    var count = 0;
    while (count++ < num) {
        console.log(count);
        await sleep(1000);
        $(".tips").click();
        console.log($(".tips").click());
        var ansString = $(".line-feed").html();
        ansString = ansString.replace('</font><font color="red">', "");
        var ans = new Array();
        ansString.split("</font>").forEach(function (value) {
            if (value.indexOf("red") !== -1) {
                var temp = value.split('<font color="red">')[1];
                if (temp != "") {
                    ans.push(temp);
                }
            }
        });
        console.log(ans);
        if ($(".q-header")[0].firstChild.nextSibling.nodeValue !== "填空题") {
            Array.prototype.slice
                .call($(".q-answer.choosable"))
                .forEach(function (value) {
                    if (ans.indexOf(value.lastChild.nodeValue) !== -1) {
                        value.click();
                    }
                });
            $(".ant-btn.next-btn.ant-btn-primary")[0].click();
        } else {
            if (ans.length == 0) {
                // 视频题无法解答
                $(".blank")[0].value = "视频题";
            } else {
                $(".blank")[0].value = ans;
            }
            // 这个处理不了，只能人为输入空格了
            $(".blank").focus();
            alert("请5s内按下两次空格，无需点击下方红色确定");
            await sleep(5000);
            $(".ant-btn.next-btn.ant-btn-primary")[0].click();
        }
        await sleep(1000);
    }
}

async function weekly() {
    window.location.href = "https://pc.xuexi.cn/points/exam-weekly-list.html";
    var btn;
    while (
        $(".ant-pagination-next").attr("class") !==
        "ant-pagination-disabled ant-pagination-next"
    ) {
        $(".ant-btn.button.ant-btn-primary").each(function () {
            if ($(this).text() == "重新答题") {
                btn = $(this);
                return false;
            }
        });
        if (btn !== undefined) {
            break;
        }
        $(".ant-pagination-next").click();
        await sleep(1000);
    }
    if (btn == undefined) {
        alert("每周答题均已作答");
        window.location.href = "https://pc.xuexi.cn/points/my-points.html";
    }
    btn.click();
}

async function item() {
    var btn;
    while (
        $(".ant-pagination-next").attr("class") !==
        "ant-pagination-disabled ant-pagination-next"
    ) {
        $(".ant-btn.button.ant-btn-primary").each(function () {
            if ($(this).text() == "已满分") {
                btn = $(this);
                return false;
            }
        });
        if (btn !== undefined) {
            break;
        }
        $(".ant-pagination-next").click();
        await sleep(1000);
    }
    if (btn == undefined) {
        alert("专项答题均已作答");
        window.location.href = "https://pc.xuexi.cn/points/my-points.html";
    }
    btn.click();
}

(async function () {
    if (
        window.location.href == "https://pc.xuexi.cn/points/exam-practice.html"
    ) {
        console.log("每日答题");
        solve(5);
    } else if (
        window.location.href ==
        "https://pc.xuexi.cn/points/exam-weekly-list.html"
    ) {
        console.log("每周答题");
        weekly();
    } else if (
        window.location.href.split("=")[0] ==
        "https://pc.xuexi.cn/points/exam-weekly-detail.html?id"
    ) {
        solve(5);
    } else if (
        window.location.href ==
        "https://pc.xuexi.cn/points/exam-paper-list.html"
    ) {
        console.log("专项答题");
        item();
    } else if (
        window.location.href.split("=")[0] ==
        "https://pc.xuexi.cn/points/exam-paper-detail.html?id"
    ) {
        solve(10);
        // 这里不知道为啥会卡住，需要手动点交卷
        console.log("test");
        $(
            ".ant-btn.submit-btn.ant-btn-primary.ant-btn-background-ghost"
        ).click();
    }
})();
